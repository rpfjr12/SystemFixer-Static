"""
programs_refresher.py — fetches bug bounty program lists and writes programs.json
in the format expected by scanner/scan.py: a list of {id, name, scope} objects.
Falls back to a built-in curated list if external sources are unreachable.
"""
import json
import os
import sys

FALLBACK_PROGRAMS = [
    {"id": "binance",      "name": "Binance",      "scope": ["https://api.binance.com", "https://www.binance.com"]},
    {"id": "cloudflare",   "name": "Cloudflare",   "scope": ["https://cloudflare.com", "https://api.cloudflare.com"]},
    {"id": "coinbase",     "name": "Coinbase",     "scope": ["https://api.coinbase.com", "https://www.coinbase.com"]},
    {"id": "digitalocean", "name": "DigitalOcean", "scope": ["https://api.digitalocean.com", "https://www.digitalocean.com"]},
    {"id": "dropbox",      "name": "Dropbox",      "scope": ["https://api.dropboxapi.com", "https://www.dropbox.com"]},
    {"id": "gitlab",       "name": "GitLab",       "scope": ["https://gitlab.com", "https://api.gitlab.com"]},
    {"id": "hackerone",    "name": "HackerOne",    "scope": ["https://hackerone.com", "https://api.hackerone.com"]},
    {"id": "kraken",       "name": "Kraken",       "scope": ["https://api.kraken.com", "https://www.kraken.com"]},
    {"id": "okta",         "name": "Okta",         "scope": ["https://developer.okta.com", "https://www.okta.com"]},
    {"id": "paypal",       "name": "PayPal",       "scope": ["https://api.paypal.com", "https://www.paypal.com"]},
    {"id": "shopify",      "name": "Shopify",      "scope": ["https://api.shopify.com", "https://www.shopify.com"]},
    {"id": "stripe",       "name": "Stripe",       "scope": ["https://api.stripe.com", "https://stripe.com"]},
]


def _fetch_bounty_targets():
    """Try to pull programs from arkadiyt/bounty-targets-data. Returns list or None."""
    try:
        import requests
        seen = set()
        programs = []
        sources = [
            "https://raw.githubusercontent.com/arkadiyt/bounty-targets-data/master/data/hackerone_data.json",
            "https://raw.githubusercontent.com/arkadiyt/bounty-targets-data/master/data/bugcrowd_data.json",
        ]
        for url in sources:
            try:
                data = requests.get(url, timeout=10).json()
                for p in data:
                    name = p.get("name") or p.get("handle") or ""
                    targets = p.get("targets", {})
                    in_scope = targets.get("in_scope", []) if isinstance(targets, dict) else []
                    urls = [t.get("target") for t in in_scope
                            if isinstance(t, dict) and t.get("target", "").startswith("http")]
                    if not urls or not name:
                        continue
                    pid = name.lower().replace(" ", "_")[:24]
                    if pid in seen:
                        continue
                    seen.add(pid)
                    programs.append({"id": pid, "name": name, "scope": urls[:3]})
            except Exception:
                continue
        return programs if programs else None
    except Exception:
        return None


def refresh_programs(output_path="programs.json"):
    programs = _fetch_bounty_targets()
    if programs:
        print(f"[programs_refresher] Fetched {len(programs)} programs from bounty-targets-data")
    else:
        programs = FALLBACK_PROGRAMS
        print(f"[programs_refresher] Using fallback list ({len(programs)} programs)")

    with open(output_path, "w") as f:
        json.dump(programs, f, indent=2)
    print(f"[programs_refresher] Wrote {output_path}")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "programs.json"
    refresh_programs(out)
