"""
severity_engine.py — normalizes severity labels and applies program rules.
Intelligence enrichment is handled separately by the pipeline.
"""
from system_fixer.severity_scoring import score_severity
from system_fixer.rules_engine import apply_rules_to_all


def run_severity_engine(findings):
    print("[severity_engine] Starting severity engine...")
    findings = score_severity(findings)
    print("[severity_engine] Severity normalized")
    findings = apply_rules_to_all(findings)
    print("[severity_engine] Program rules applied")
    print("[severity_engine] Severity engine complete")
    return findings
