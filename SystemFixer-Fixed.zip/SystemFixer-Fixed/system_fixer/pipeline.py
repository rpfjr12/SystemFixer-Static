"""
pipeline.py — unified analysis pipeline for SystemFixer.

Flow:
  load → normalize → filter FP → severity → enrich → money → reports → dashboard
"""
import os
import sys

# Ensure repo root is on path when running from any working directory
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)
os.chdir(_REPO_ROOT)

from system_fixer.findings_loader import load_findings
from system_fixer.findings_normalizer import normalize_findings
from system_fixer.false_positive_filter import filter_false_positives
from system_fixer.severity_scoring import score_severity
from system_fixer.rules_engine import apply_rules_to_all
from system_fixer.intelligence_enricher import enrich_findings
from system_fixer.money_filter import apply_money_filter
from system_fixer.money_ranker import rank_findings_by_money
from system_fixer.output_writer import write_output
from system_fixer.report_generator import generate_reports
from system_fixer.dashboard_writer import write_dashboard


def run_pipeline():
    print("[pipeline] Starting unified analysis pipeline...")

    # 1. Load raw findings from data/scan_results.json
    findings = load_findings()
    print(f"[pipeline] Loaded {len(findings)} raw findings")

    if not findings:
        print("[pipeline] WARNING: No findings to process. Run the scanner first.")
        return []

    # 2. Normalize structure
    findings = normalize_findings(findings)
    print("[pipeline] Normalized findings")

    # 3. Remove false positives
    findings = filter_false_positives(findings)
    print("[pipeline] Filtered false positives")

    # 4. Severity normalization
    findings = score_severity(findings)
    print("[pipeline] Severity scoring complete")

    # 5. Program-specific rules
    findings = apply_rules_to_all(findings)
    print("[pipeline] Program rules applied")

    # 6. Intelligence enrichment (once only)
    findings = enrich_findings(findings)
    print("[pipeline] Intelligence enrichment complete")

    # 7. Money scoring + filter + ranking
    findings = apply_money_filter(findings, min_score=0)   # score all, no threshold cutoff
    findings = rank_findings_by_money(findings)
    print("[pipeline] Money pipeline complete")

    # 8. Write output/final_findings.json
    write_output(findings)
    print("[pipeline] Wrote processed findings")

    # 9. Generate per-finding markdown reports
    generate_reports(findings)
    print("[pipeline] Reports generated")

    # 10. Update dashboard/data.js
    write_dashboard(findings)
    print("[pipeline] Dashboard updated")

    print(f"[pipeline] Pipeline complete — {len(findings)} findings processed")
    return findings


if __name__ == "__main__":
    run_pipeline()
