import json
import os

# Primary file produced by scanner/scan.py
SCAN_RESULTS_FILE = "data/scan_results.json"
# Legacy fallback
RAW_FINDINGS_FILE = "raw_findings.json"


def load_findings():
    # 1. Prefer aggregated scan results
    for path in [SCAN_RESULTS_FILE, RAW_FINDINGS_FILE]:
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list) and len(data) > 0:
                    print(f"[findings_loader] Loaded {len(data)} findings from {path}")
                    return data
                else:
                    print(f"[findings_loader] {path} exists but is empty, trying next source")
            except Exception as e:
                print(f"[findings_loader] Error reading {path}: {e}")

    # 2. Fall back to aggregating all per-program data/*.json files
    print("[findings_loader] Falling back to aggregating data/*.json files")
    return _aggregate_data_dir()


def _aggregate_data_dir():
    """Collect all findings from dated per-program JSON files in data/."""
    data_dir = "data"
    if not os.path.isdir(data_dir):
        print("[findings_loader] data/ directory not found — returning empty list")
        return []

    all_findings = []
    for fname in sorted(os.listdir(data_dir)):
        if not fname.endswith(".json"):
            continue
        # Skip the aggregate file itself and gitkeep
        if fname in ("scan_results.json",):
            continue
        path = os.path.join(data_dir, fname)
        try:
            with open(path, "r", encoding="utf-8") as f:
                items = json.load(f)
            if isinstance(items, list):
                all_findings.extend(items)
        except Exception as e:
            print(f"[findings_loader] Skipping {fname}: {e}")

    print(f"[findings_loader] Aggregated {len(all_findings)} findings from data/")
    return all_findings
