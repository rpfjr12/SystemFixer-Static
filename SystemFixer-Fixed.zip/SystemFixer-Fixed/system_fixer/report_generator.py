"""
report_generator.py — generates per-program Markdown reports.
"""
import os
import json
from datetime import datetime
from collections import defaultdict

OUTPUT_DIR = "reports"


def ensure_output_dir():
    os.makedirs(OUTPUT_DIR, exist_ok=True)


def generate_program_report(program_name, findings):
    date = datetime.utcnow().strftime("%Y-%m-%d")
    lines = [
        f"# {program_name} — Security Findings Report",
        f"",
        f"**Generated:** {datetime.utcnow().isoformat()} UTC  ",
        f"**Total Findings:** {len(findings)}  ",
        f"",
        f"---",
        f"",
    ]

    # Severity summary
    counts = defaultdict(int)
    for f in findings:
        counts[f.get("severity", "UNRATED")] += 1
    lines.append("## Severity Summary")
    lines.append("")
    for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "UNRATED"]:
        if counts[sev]:
            lines.append(f"- **{sev}**: {counts[sev]}")
    lines.append("")
    lines.append("---")
    lines.append("")

    # Individual findings
    lines.append("## Findings")
    lines.append("")
    for i, f in enumerate(findings, 1):
        title = f.get("title", "Untitled")
        target = f.get("target", "")
        sev = f.get("severity", "UNRATED")
        desc = f.get("description", "No description.")
        repro = f.get("reproduction_steps", "Not provided.")
        impact = f.get("impact", "Not provided.")
        money_score = f.get("money_score", 0)
        fingerprint = f.get("fingerprint", "")

        lines += [
            f"### {i}. {title}",
            f"",
            f"**Severity:** {sev}  ",
            f"**Target:** `{target}`  ",
            f"**Money Score:** {money_score}  ",
            f"**Fingerprint:** `{fingerprint}`  ",
            f"",
            f"**Description:**  ",
            f"{desc}",
            f"",
            f"**Steps to Reproduce:**  ",
            f"{repro}",
            f"",
            f"**Impact:**  ",
            f"{impact}",
            f"",
            f"---",
            f"",
        ]

    return "\n".join(lines)


def write_report_file(program_name, findings):
    ensure_output_dir()
    date = datetime.utcnow().strftime("%Y-%m-%d")
    safe_name = program_name.replace("/", "_").replace(" ", "-")
    filename = os.path.join(OUTPUT_DIR, f"{safe_name}-{date}.md")
    content = generate_program_report(program_name, findings)
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[report_generator] Wrote: {filename}")
    return filename


def generate_reports(findings):
    print(f"[report_generator] Generating reports for {len(findings)} findings...")
    # Group by program
    by_program = defaultdict(list)
    for f in findings:
        by_program[f.get("program", "Unknown")].append(f)

    for program_name, program_findings in sorted(by_program.items()):
        write_report_file(program_name, program_findings)

    print(f"[report_generator] Generated {len(by_program)} program reports")


# Legacy single-finding report (kept for backwards compatibility)
def generate_markdown_report(finding):
    title = finding.get("title", "Untitled Finding")
    program = finding.get("program", "Unknown Program")
    target = finding.get("target", "Unknown Target")
    severity = finding.get("severity", "Unrated")
    description = finding.get("description", "No description provided.")
    reproduction = finding.get("reproduction_steps", "No reproduction steps provided.")
    impact = finding.get("impact", "No impact provided.")
    fingerprint = finding.get("fingerprint", "no-fingerprint")
    money_score = finding.get("money_score", 0)

    return f"""# {title}

**Program:** {program}
**Target:** {target}
**Severity:** {severity}
**Money Score:** {money_score}
**Fingerprint:** `{fingerprint}`
**Generated:** {datetime.utcnow().isoformat()} UTC

---

## Summary
{description}

---

## Steps to Reproduce
{reproduction}

---

## Impact
{impact}
"""
