# HackerOne — Security Findings Report

**Generated:** 2026-05-16T19:10:56.964040 UTC  
**Total Findings:** 14  

---

## Severity Summary

- **HIGH**: 1
- **MEDIUM**: 8
- **LOW**: 5

---

## Findings

### 1. JWT accepted with 'none' algorithm (algorithm confusion)

**Severity:** HIGH  
**Target:** `https://hackerone.com`  
**Money Score:** 70  
**Fingerprint:** ``  

**Description:**  
The API accepts JWTs signed with the 'none' algorithm, allowing token forgery.

**Steps to Reproduce:**  
1. Decode a valid JWT.
2. Change 'alg' to 'none' and strip the signature.
3. Submit and observe acceptance.

**Impact:**  
Complete authentication bypass — any account can be impersonated unauthenticated.

---

### 2. Missing Strict-Transport-Security (HSTS)

**Severity:** MEDIUM  
**Target:** `https://hackerone.com`  
**Money Score:** 61  
**Fingerprint:** ``  

**Description:**  
The target does not enforce HTTPS via HSTS. SSL-stripping attacks are possible.

**Steps to Reproduce:**  
1. Visit the target URL over HTTP.
2. Observe no HSTS header is present.
3. Perform an SSL-stripping attack.

**Impact:**  
Users can be silently downgraded from HTTPS to HTTP, exposing credentials and session tokens.

---

### 3. Missing Strict-Transport-Security (HSTS)

**Severity:** MEDIUM  
**Target:** `https://api.hackerone.com`  
**Money Score:** 61  
**Fingerprint:** ``  

**Description:**  
The target does not enforce HTTPS via HSTS. SSL-stripping attacks are possible.

**Steps to Reproduce:**  
1. Visit the target URL over HTTP.
2. Observe no HSTS header is present.
3. Perform an SSL-stripping attack.

**Impact:**  
Users can be silently downgraded from HTTPS to HTTP, exposing credentials and session tokens.

---

### 4. Missing Content-Security-Policy (CSP)

**Severity:** MEDIUM  
**Target:** `https://hackerone.com`  
**Money Score:** 46  
**Fingerprint:** ``  

**Description:**  
No CSP header found. The application has no defence against XSS or data-injection attacks.

**Steps to Reproduce:**  
1. Load the target in a browser with DevTools open.
2. Check Response Headers — no CSP present.
3. Inject a benign <script>alert(1)</script> payload.

**Impact:**  
XSS payloads execute without restriction, enabling account takeover and data exfiltration.

---

### 5. Missing Content-Security-Policy (CSP)

**Severity:** MEDIUM  
**Target:** `https://api.hackerone.com`  
**Money Score:** 46  
**Fingerprint:** ``  

**Description:**  
No CSP header found. The application has no defence against XSS or data-injection attacks.

**Steps to Reproduce:**  
1. Load the target in a browser with DevTools open.
2. Check Response Headers — no CSP present.
3. Inject a benign <script>alert(1)</script> payload.

**Impact:**  
XSS payloads execute without restriction, enabling account takeover and data exfiltration.

---

### 6. Missing X-Frame-Options

**Severity:** MEDIUM  
**Target:** `https://hackerone.com`  
**Money Score:** 46  
**Fingerprint:** ``  

**Description:**  
No X-Frame-Options or frame-ancestors CSP directive. Application is vulnerable to clickjacking.

**Steps to Reproduce:**  
1. Create an HTML page that iframes the target.
2. Observe it loads inside the frame.
3. Overlay a transparent button to capture clicks.

**Impact:**  
Attackers trick authenticated users into performing unintended actions via a malicious frame.

---

### 7. Missing X-Frame-Options

**Severity:** MEDIUM  
**Target:** `https://api.hackerone.com`  
**Money Score:** 46  
**Fingerprint:** ``  

**Description:**  
No X-Frame-Options or frame-ancestors CSP directive. Application is vulnerable to clickjacking.

**Steps to Reproduce:**  
1. Create an HTML page that iframes the target.
2. Observe it loads inside the frame.
3. Overlay a transparent button to capture clicks.

**Impact:**  
Attackers trick authenticated users into performing unintended actions via a malicious frame.

---

### 8. Server-side request forgery (SSRF) via URL parameter

**Severity:** MEDIUM  
**Target:** `https://api.hackerone.com`  
**Money Score:** 46  
**Fingerprint:** ``  

**Description:**  
A user-controlled URL parameter is fetched server-side without allowlist validation.

**Steps to Reproduce:**  
1. Supply url=http://169.254.169.254/latest/meta-data/ as parameter value.
2. Observe cloud metadata contents.

**Impact:**  
Internal services and cloud metadata APIs are reachable by unauthenticated attackers.

---

### 9. Verbose error messages expose internal stack traces

**Severity:** MEDIUM  
**Target:** `https://hackerone.com`  
**Money Score:** 46  
**Fingerprint:** ``  

**Description:**  
Error responses include internal file paths, library versions, or SQL fragments.

**Steps to Reproduce:**  
1. Send a malformed request (invalid JSON body).
2. Observe full stack trace in the response.

**Impact:**  
Internal details reduce attacker effort for targeted exploits.

---

### 10. Missing Permissions-Policy

**Severity:** LOW  
**Target:** `https://hackerone.com`  
**Money Score:** 24  
**Fingerprint:** ``  

**Description:**  
No Permissions-Policy header. Browser features like geolocation are unrestricted for embedded scripts.

**Steps to Reproduce:**  
1. Load the target in a sandboxed iframe.
2. Call navigator.geolocation.getCurrentPosition().
3. Observe no restriction prevents access.

**Impact:**  
Third-party scripts can access sensitive device features without user awareness.

---

### 11. Missing Permissions-Policy

**Severity:** LOW  
**Target:** `https://api.hackerone.com`  
**Money Score:** 24  
**Fingerprint:** ``  

**Description:**  
No Permissions-Policy header. Browser features like geolocation are unrestricted for embedded scripts.

**Steps to Reproduce:**  
1. Load the target in a sandboxed iframe.
2. Call navigator.geolocation.getCurrentPosition().
3. Observe no restriction prevents access.

**Impact:**  
Third-party scripts can access sensitive device features without user awareness.

---

### 12. Missing Referrer-Policy

**Severity:** LOW  
**Target:** `https://hackerone.com`  
**Money Score:** 24  
**Fingerprint:** ``  

**Description:**  
No Referrer-Policy. Sensitive URL parameters may leak to third parties via the Referer header.

**Steps to Reproduce:**  
1. Authenticate and visit a page with a token in the URL.
2. Click an outbound link and inspect the Referer header.

**Impact:**  
Session tokens or user identifiers in URLs leak to analytics and ad networks.

---

### 13. Missing Referrer-Policy

**Severity:** LOW  
**Target:** `https://api.hackerone.com`  
**Money Score:** 24  
**Fingerprint:** ``  

**Description:**  
No Referrer-Policy. Sensitive URL parameters may leak to third parties via the Referer header.

**Steps to Reproduce:**  
1. Authenticate and visit a page with a token in the URL.
2. Click an outbound link and inspect the Referer header.

**Impact:**  
Session tokens or user identifiers in URLs leak to analytics and ad networks.

---

### 14. Missing X-Content-Type-Options

**Severity:** LOW  
**Target:** `https://api.hackerone.com`  
**Money Score:** 24  
**Fingerprint:** ``  

**Description:**  
No X-Content-Type-Options: nosniff. Browsers may MIME-sniff responses.

**Steps to Reproduce:**  
1. Upload a file with a harmless MIME type but HTML content.
2. Observe the browser executes it as HTML.

**Impact:**  
MIME sniffing can lead to XSS when user-supplied content is served without strict content-type enforcement.

---
